/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # URL Scheme
 */

/*:
 ### X.app – Playground Book – ContentIdentifier:
 - playground.x.book
 */

/*:
 ### X.app – Universal Link:
 - Website: [https://developer.apple.com/ul/sp0?url=https://extension.app/whimsical-swift/feed.json](https://developer.apple.com/ul/sp0?url=https://extension.app/whimsical-swift/feed.json)
 - App: [https://developer.apple.com/ul/sp0?url=https://extension.app/playground-app/whimsical-swift/feed.json](https://developer.apple.com/ul/sp0?url=https://extension.app/playground-app/whimsical-swift/feed.json)
 - Book: [https://developer.apple.com/ul/sp0?url=https://extension.app/playground-book/whimsical-swift/feed.json](https://developer.apple.com/ul/sp0?url=https://extension.app/playground-book/whimsical-swift/feed.json)
 */


/*:
 ### Swift Playgrounds – URL Scheme:
 
 - Open Swift Playgrounds: 
 [x-com-apple-playgrounds://](x-com-apple-playgrounds://)
 
 - Open Swift Playgrounds/Projects:
 [x-com-apple-playgrounds://projects](x-com-apple-playgrounds://projects)
 
 - Open Swift Playgrounds/Projects – List:
 [x-com-apple-playgrounds://projects?contentId=com.apple](x-com-apple-playgrounds://projects?contentId=com.apple)
 
 - Open Swift Playgrounds/Projects – App:
 [x-com-apple-playgrounds://projects?contentId=playground.x.app](x-com-apple-playgrounds://projects?contentId=playground.x.app)
 
 - Open Swift Playgrounds/Projects – Book:
 [x-com-apple-playgrounds://projects?contentId=playground.x.book](x-com-apple-playgrounds://projects?contentId=playground.x.book)
 
 - Open Swift Playgrounds/Projects - Example – AboutMe:
 [x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.aboutme](x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.aboutme)
 
 - Open Swift Playgrounds/Projects - Example – Battleship:
 [x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.battleship.edition3](x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.battleship.edition3)
 
 - Open Swift Playgrounds/Documents:
 [x-com-apple-playgrounds://documents](x-com-apple-playgrounds://documents)
 
 - Open Swift Playgrounds/Documents – List:
 [x-com-apple-playgrounds://documents?documentId=com.apple](x-com-apple-playgrounds://documents?documentId=com.apple)
 
 - Open Swift Playgrounds/Documents - Example – AboutMe:
 [x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.aboutme](x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.aboutme)
 
 - Open Swift Playgrounds/Documents - Example – Battleship:
 [x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.battleship.edition3](x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.battleship.edition3)
 */


/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 */
