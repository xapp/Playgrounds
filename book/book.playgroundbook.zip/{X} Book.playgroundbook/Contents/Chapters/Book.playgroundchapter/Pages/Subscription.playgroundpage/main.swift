/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # Subscription
 */

/*:
 ### Subscription URL:
 - [extension.app](https://extension.app)
 - [https://developer.apple.com/ul/sp0?url=https://extension.app/whimsical-swift/feed.json](https://developer.apple.com/ul/sp0?url=https://extension.app/whimsical-swift/feed.json)
 */

/*:
 ### Manual on Mac:
 1. Press File > Add Subscription in menu bar.
 2. Input ["https://extension.app"](https://extension.app).
 3. Press "Subscribe" button.
 */

/*:
 ### Manual on iPad:
 1. Open Swift Playgrounds app.
 2. Press "See All" at the bottom row.
 3. Scroll to botton and select "Enter a Subscription URL".
 4. Input ["https://extension.app"](https://extension.app).
 5. Press "Subscribe" button.
 */

/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 */
