/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # Circle
 */



import PlaygroundSupport
import SwiftUI

struct CircleView: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.yellow)
            Image(systemName: "circle.hexagonpath.fill")
                .font(.system(size: 100, weight: .bold))
        }
    }
}

struct CircleView_Preview: PreviewProvider {
    static var previews: some View {
        CircleView()
    }
}

PlaygroundPage.current.liveView = UIHostingController(rootView: CircleView())



/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 */
