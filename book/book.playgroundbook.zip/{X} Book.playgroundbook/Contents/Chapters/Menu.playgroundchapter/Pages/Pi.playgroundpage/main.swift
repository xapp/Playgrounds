/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # Pi
 */



let pi = Double.pi
print(pi)



/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 */
