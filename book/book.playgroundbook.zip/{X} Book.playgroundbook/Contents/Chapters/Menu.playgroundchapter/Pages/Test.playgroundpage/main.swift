/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # Test
 */

import PlaygroundSupport
import SwiftUI


struct CircleView: View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "bot@2x")!)  
        }
    }
}

PlaygroundPage.current.liveView = UIHostingController(rootView: CircleView())


/*:
 - [Contents](Book/Contents) | [< Previous Page](@previous) | [Next Page >](@next)
 */
