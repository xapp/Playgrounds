import UIKit

public class BookTest {
    
    public var test: String
    
    public init(test: String) {
        self.test = test
    }

    public func run() {
        print(self.test)
    }
}
