import SwiftUI

struct ViewController<ViewController: UIViewController>: View {
    var body: some View {
        ViewControllerRepresentable<ViewController>()
    } 
}

struct ViewControllerRepresentable<ViewController: UIViewController>: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> some UIViewController {
        return ViewController()
    }
    
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }
}
