import SwiftUI

extension View {
    func printOutput(_ value: Any) -> Self {
        print(value)
        return self
    }
}
