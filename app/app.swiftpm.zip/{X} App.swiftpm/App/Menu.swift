import SwiftUI

struct MenuView: View {
    var body: some View {
        
        NavigationSplitView {
            List {
                Section(header: Text("Interface")) {
                    NavigationLink {
                        SwiftUIView()
                            .navigationTitle("SwiftUI")
                    } label: {
                        Label("SwiftUI", systemImage: "swift")
                    }
                    
                    NavigationLink { 
                        ViewController<XUIKitView_Controller>()
                            .navigationTitle("Test")
                    } label: {
                        Label("UIKit", systemImage: "uiwindow.split.2x1")
                    }
                    
                    NavigationLink { 
                        XDebuggingView()
                            .navigationTitle("Debugging")
                    } label: {
                        Label("Debugging", systemImage: "ant")
                    }
                }
                
                
                Section(header: Text("Extension")) {
                    
                    NavigationLink { 
                        XCircleView()
                            .navigationTitle("Circle")
                    } label: {
                        Label("Cirle", systemImage: "circle")
                    }
                    
                    NavigationLink { 
                        XColorView()
                            .navigationTitle("Color")
                    } label: {
                        Label("Color", systemImage: "circle.hexagongrid")
                    }
                    
                    NavigationLink { 
                        XContactsView()
                            .navigationTitle("Contacts")
                    } label: {
                        Label("Contacts", systemImage: "person")
                    }
                    
                    NavigationLink { 
                        ViewController<XImageView_Controller>()
                            .navigationTitle("Image")
                    } label: {
                        Label("Image", systemImage: "photo")
                    }
                    
                    NavigationLink { 
                        XLinkView()
                            .navigationTitle("Link")
                    } label: {
                        Label("Link", systemImage: "link")
                    }
                }
            }
            .navigationTitle("Menu")
        } detail: {}
    }
}

struct MenuView_Preview: PreviewProvider {
    static var previews: some View {
        MenuView()
    }
}
