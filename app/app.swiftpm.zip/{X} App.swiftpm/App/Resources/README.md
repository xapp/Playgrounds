X.app is an All-in-One Extension App, available on the App Store [App Store](https://apps.apple.com/app/x-app/id1533525753).

X.app provides this Playground to provide additional capabilities and extensions.

For more information, visit [X.app/Playgrounds](https://extension.app/playgrounds).
