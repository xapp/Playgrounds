import SwiftUI

@main
struct XApp: App {
    var body: some Scene {
        WindowGroup {
            MenuView()
        }
    }
}
