import SwiftUI

struct XColorView: View {
    let columnLayout = Array(repeating: /*#-code-walkthrough(changeGridItem)*/ GridItem() /*#-code-walkthrough(changeGridItem)*/, count: 3)
    
    let allColors: [Color] = [.pink, .red, .orange, .yellow, .green, .mint, .teal, .cyan, .blue, .indigo, .purple, .brown, .gray]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columnLayout) {
                /*#-code-walkthrough(2.lazyVGrid)*/
                /*#-code-walkthrough(2.gridForEach)*/
                ForEach(allColors.indices, id: \.self) { index in
                    /*#-code-walkthrough(2.gridForEach)*/
                    //#-learning-code-snippet(addButton)
                    /*#-code-walkthrough(2.gridLabel)*/
                    RoundedRectangle(cornerRadius: 5.0)
                        .aspectRatio(1.0, contentMode: ContentMode.fit)
                        .foregroundColor(allColors[index])
                    /*#-code-walkthrough(2.gridLabel)*/
                }
            }
        }
        .padding()
    }
}

struct XColorView_Preview: PreviewProvider {
    static var previews: some View {
        XColorView()
    }
}
