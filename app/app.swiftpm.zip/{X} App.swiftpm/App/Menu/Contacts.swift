import SwiftUI
import Contacts

struct XContactsView: View {
    let columnLayout = Array(repeating: /*#-code-walkthrough(changeGridItem)*/ GridItem() /*#-code-walkthrough(changeGridItem)*/, count: 3)
    
    let allColors: [Color] = [.pink, .red, .orange, .yellow, .green, .mint, .teal, .cyan, .blue, .indigo, .purple, .brown, .gray]
    
    var body: some View {
        VStack {
            Button("Contact") {
                Task {
                    await self.contacts()
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)
        }
    }
    
    
    func contacts() async {
        do {
            let store = CNContactStore()
            if try await store.requestAccess(for: .contacts) {
                // Do something with Contacts.
                print("Contacts: access is granted")
            } else {
                // Handle if Contacts access is denied.
                print("Contacts: access is denied")
            }
        } catch {
            // Handle any error.
            print("Contacts: error")
        }
    }
}

struct XContactsView_Preview: PreviewProvider {
    static var previews: some View {
        XContactsView()
    }
}


