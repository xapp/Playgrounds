import SwiftUI
import UIKit

class XImageView_Controller: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .yellow
        
        let image = UIImageView(image: UIImage(named: "Menu"))
        image.contentMode = .scaleAspectFit
        image.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addSubview(image)
        self.view.topAnchor.constraint(equalTo: image.topAnchor).isActive = true
        self.view.leadingAnchor.constraint(equalTo: image.leadingAnchor).isActive = true
        self.view.trailingAnchor.constraint(equalTo: image.trailingAnchor).isActive = true
        self.view.bottomAnchor.constraint(equalTo: image.bottomAnchor).isActive = true
    }
}

struct XImageView: View {
    var body: some View {
        ViewControllerRepresentable<XImageView_Controller>()
    } 
}

struct XImageView_Preview: PreviewProvider {
    static var previews: some View {
        XImageView()
    }
}
