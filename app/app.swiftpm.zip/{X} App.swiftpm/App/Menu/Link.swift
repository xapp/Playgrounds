import SwiftUI
import XPlaygroundPackage

struct XLinkView: View {
    var body: some View {
        VStack {
            Button("X.app") {
                XLink.openURL(url: URL(string: "https://extension.app")!, options: [:]) { completed in
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.pink)
        }
    }
}

struct XLinkView_Preview: PreviewProvider {
    static var previews: some View {
        XLinkView()
    }
}
