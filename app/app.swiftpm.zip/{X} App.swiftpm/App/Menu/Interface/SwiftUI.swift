import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("X - SwiftUI")
        }
    }
}

struct SwiftUIView_Preview: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
