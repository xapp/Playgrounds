import SwiftUI
import UIKit

class XUIKitView_Controller: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .yellow
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "X - UIKit"
        
        self.view.addSubview(label)
        self.view.centerXAnchor.constraint(equalTo: label.centerXAnchor).isActive = true
        self.view.centerYAnchor.constraint(equalTo: label.centerYAnchor).isActive = true
    }
}

struct XUIKitView: View {
    var body: some View {
        ViewControllerRepresentable<XUIKitView_Controller>()
    } 
}

struct XUIKitView_Preview: PreviewProvider {
    static var previews: some View {
        XUIKitView()
        //ViewController<XUIKitView_Controller>()
    }
}

