import SwiftUI

struct XDebuggingView: View {
    var body: some View {
        VStack {
            
            // 1. debug with print: .onAppear 
            Circle()
                .fill(Color.yellow)
                .onAppear {
                    print("X: onAppear")
                }
            
            // 2. debug with print: on return
            Circle()
                .fill(Color.red)
                .printOutput("X: on return")

            // 3. debug with _printChanges – property caused the view to update
            let _ = Self._printChanges()
        }
    }
}

struct XDebuggingView_Preview: PreviewProvider {
    static var previews: some View {
        XDebuggingView()
    }
}
